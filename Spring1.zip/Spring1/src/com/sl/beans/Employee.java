package com.sl.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Employee {

	private String name;
	private int id;
	
	@Autowired
	@Qualifier("createProject2")
	private Project project;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	public Project getProject() {
		return project;
	}
	public void setProject(Project project) {
		System.out.println("Project setting by set mehtod Agiaan");
		this.project = project;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Name: " + name + " ID: " + id + " proejct: " + project;
	}
}

package com.sl.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//@Component
public class Project {
	
	//@Value("123")
	private int projectId;
	
	//@Value("SwissRe provides re insurance to the insurance companies.")
	private String projectDescription;
	
	
	
	
	public int getProjectId() {
		return projectId;
	}




	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}




	public String getProjectDescription() {
		return projectDescription;
	}




	public void setProjectDescription(String projectDescription) {
		this.projectDescription = projectDescription;
	}




	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "projectId: " + projectId + " Description: " + projectDescription;
	}

}

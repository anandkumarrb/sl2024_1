package com.sl.resources;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.sl.beans.Employee;
import com.sl.beans.Project;

@Configuration
public class BeanConfiguration {

	@Bean
	public Project createProject1() {
		
		Project p = new Project();
		
		p.setProjectDescription("TCS is consultancy serivce");
		p.setProjectId(2333);
		return p;
	}
	
	@Bean
	public Project createProject2() {
		
		Project p = new Project();
		
		p.setProjectDescription("Swissre is reinsraunce compnay.");
		p.setProjectId(5555);
		return p;
	}
	
	@Bean
	public Employee createEmpObj() {
		Employee e = new Employee();
		e.setId(1335353);
		e.setName("Anand");
		//e.setProject(createProject()); ///Mnually DI
		return e;
	}
	
	
}

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sl.beans.Employee;
import com.sl.beans.Project;
import com.sl.resources.BeanConfiguration;

public class SpringMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//ApplicationContext context = new ClassPathXmlApplicationContext("/com/sl/resources/applicationContext.xml");
		
		ApplicationContext context = new AnnotationConfigApplicationContext(BeanConfiguration.class);
		
		//ApplicationContext context = new AnnotationConfigApplicationContext(BeanConfiguration.class);
		
		Employee employee = (Employee) context.getBean("createEmpObj");
		System.out.println(employee);
		
		System.out.println("Working!");
	}

}
